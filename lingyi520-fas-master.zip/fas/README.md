# FAS3.0 凌一破解Shell版
FAS3.0 stream control script 一键脚本


```
wget https://gitee.com/lingyi520/fas/raw/master/fas.sh;bash fas.sh
```