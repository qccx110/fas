<?php if(!defined('INCLUDE_PATH')){die('error!this is a cache file!');};?><?php template('public_html/head2',$this->vars); ?>
<div class="system-tips">
	<?php echo $content;?>
</div>
<?php template('public_html/footer2',$this->vars); ?>